
int math_add(int n1, int n2)
{
	return n1+n2;
}


int math_sub(int n1, int n2)
{
   return n1-n2;
}


long long int math_mul(int n1, int n2)
{
	return (long long int )n1 * n2 ;
}


float math_div(int n1, int n2)
{
    return (float)n1 / n2;
}
